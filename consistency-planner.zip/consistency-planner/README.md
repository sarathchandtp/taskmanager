# 🔥 Consistency Planner

A personal productivity app — todo list, weekly timetable, monthly/yearly goals, and progress tracking.

## Features
- 📋 3-tier Todo (Must / Should / Someday)
- 🗓 Weekly timetable with 30-min slots — tap to mark complete
- 🎯 Monthly & yearly goals with progress tracking
- 📈 Progress dashboard with heatmap & streaks
- 💾 All data saved automatically to your browser (localStorage)

---

## Deploy to Vercel in 3 steps (free, takes 5 minutes)

### Step 1 — Push to GitHub
1. Go to [github.com/new](https://github.com/new) and create a new repo (e.g. `consistency-planner`)
2. Upload all these files (drag and drop works in GitHub's UI)
   - Or use git:
     ```
     git init
     git add .
     git commit -m "initial commit"
     git remote add origin https://github.com/YOUR_USERNAME/consistency-planner.git
     git push -u origin main
     ```

### Step 2 — Deploy on Vercel
1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **"Add New Project"**
3. Select your `consistency-planner` repo
4. Vercel auto-detects Vite — just click **"Deploy"**
5. In ~60 seconds you get a live URL like `https://consistency-planner.vercel.app`

### Step 3 — Done!
- Bookmark the URL on your phone and desktop
- Add it to your phone's home screen (share → "Add to Home Screen" on iOS/Android)
- Data saves in the browser — no login needed

---

## Run locally (optional)
```bash
npm install
npm run dev
```
Then open http://localhost:5173

---

## Data storage
All your data is stored in **localStorage** in your browser.
- ✅ Survives page refreshes and tab closes
- ✅ Works offline
- ⚠️ Clearing browser data / cookies will wipe it
- ⚠️ Data does not sync across devices (each browser has its own copy)

If you want cross-device sync in the future, the next step is adding [Supabase](https://supabase.com) (free tier) as a backend.
