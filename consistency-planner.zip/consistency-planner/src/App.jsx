import { useState, useEffect } from "react";

// ── helpers ──────────────────────────────────────────────────────────────────
const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const SLOTS = Array.from({ length: 32 }, (_, i) => i); // 6:00–21:30

function slotToTime(slot) {
  const totalMins = 6 * 60 + slot * 30;
  const h = Math.floor(totalMins / 60);
  const m = totalMins % 60;
  const ampm = h >= 12 ? "PM" : "AM";
  const displayH = h > 12 ? h - 12 : h === 0 ? 12 : h;
  return `${displayH}:${m === 0 ? "00" : "30"} ${ampm}`;
}
function slotToLabel(slot) {
  const totalMins = 6 * 60 + slot * 30;
  if (totalMins % 60 !== 0) return "";
  const h = Math.floor(totalMins / 60);
  return `${h > 12 ? h - 12 : h}${h >= 12 ? "PM" : "AM"}`;
}
function fmtDate(d) { return d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }); }
function fmtTime(d) { return d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }); }

const nowDate = new Date();
const CURRENT_MONTH = nowDate.toLocaleString("en-IN", { month: "long" });
const CURRENT_YEAR  = nowDate.getFullYear();
const daysInMonth   = new Date(CURRENT_YEAR, nowDate.getMonth() + 1, 0).getDate();
const dayOfMonth    = nowDate.getDate();
const dayOfYear     = Math.floor((nowDate - new Date(CURRENT_YEAR, 0, 0)) / 86400000);

// ── localStorage hook ─────────────────────────────────────────────────────────
function useLocalStorage(key, initial) {
  const [value, setValue] = useState(() => {
    try {
      const stored = localStorage.getItem(key);
      return stored ? JSON.parse(stored) : initial;
    } catch { return initial; }
  });
  useEffect(() => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  }, [key, value]);
  return [value, setValue];
}

// ── constants ─────────────────────────────────────────────────────────────────
const COLORS = ["#FF6B6B","#FFD93D","#6BCB77","#4D96FF","#C77DFF","#FF9A3C","#00C9A7"];
const DURATIONS = [
  { label:"30m", value:1 },{ label:"1h", value:2 },
  { label:"1.5h", value:3 },{ label:"2h", value:4 },{ label:"3h", value:6 },
];
const SLOT_H = 18;

const WEEK_HISTORY = [
  { week:"May 12", days:{ Mon:{done:2,total:3},Tue:{done:3,total:3},Wed:{done:1,total:3},Thu:{done:3,total:3},Fri:{done:2,total:3},Sat:{done:0,total:2},Sun:{done:1,total:2} } },
  { week:"May 19", days:{ Mon:{done:3,total:3},Tue:{done:2,total:3},Wed:{done:3,total:3},Thu:{done:1,total:3},Fri:{done:3,total:3},Sat:{done:2,total:2},Sun:{done:2,total:2} } },
  { week:"May 26", days:{ Mon:{done:2,total:3},Tue:{done:3,total:3},Wed:{done:2,total:3},Thu:{done:3,total:3},Fri:{done:3,total:3},Sat:{done:1,total:2},Sun:{done:0,total:2} } },
  { week:"Jun 2",  days:{ Mon:{done:3,total:3},Tue:{done:3,total:3},Wed:{done:2,total:3},Thu:{done:3,total:3},Fri:{done:0,total:3},Sat:{done:0,total:2},Sun:{done:0,total:2} } },
];

const DEFAULT_TASKS = [
  { id:1, text:"Plan the week ahead", tier:"must", done:false },
  { id:2, text:"Read for 30 minutes", tier:"should", done:false },
  { id:3, text:"Exercise", tier:"must", done:false },
];
const DEFAULT_BLOCKS = [
  { id:1, day:"Mon", slot:2,  label:"Deep Work",   color:"#4D96FF", duration:4 },
  { id:2, day:"Mon", slot:28, label:"Review+Plan",  color:"#C77DFF", duration:2 },
  { id:3, day:"Wed", slot:2,  label:"Deep Work",   color:"#4D96FF", duration:4 },
  { id:4, day:"Fri", slot:2,  label:"Deep Work",   color:"#4D96FF", duration:4 },
  { id:5, day:"Sun", slot:8,  label:"Weekly Reset",color:"#6BCB77", duration:2 },
];
const DEFAULT_MONTH_GOALS = [
  { id:101, scope:"month", title:"Exercise 20 times",  category:"Health",   color:"#6BCB77", target:20,    current:7,    unit:"sessions", notes:"", done:false },
  { id:102, scope:"month", title:"Read 2 books",       category:"Learning", color:"#4D96FF", target:2,     current:1,    unit:"books",    notes:"", done:false },
  { id:103, scope:"month", title:"Save ₹15,000",       category:"Finance",  color:"#FFD93D", target:15000, current:8000, unit:"₹",        notes:"", done:false },
];
const DEFAULT_YEAR_GOALS = [
  { id:201, scope:"year", title:"Read 24 books",            category:"Learning", color:"#4D96FF", target:24,     current:9,  unit:"books",    notes:"", done:false },
  { id:202, scope:"year", title:"Run a half marathon",      category:"Health",   color:"#6BCB77", target:1,      current:0,  unit:"races",    notes:"Train by Oct", done:false },
  { id:203, scope:"year", title:"Build 3 side projects",    category:"Work",     color:"#C77DFF", target:3,      current:1,  unit:"projects", notes:"", done:false },
  { id:204, scope:"year", title:"SIP corpus ₹1L milestone", category:"Finance",  color:"#FFD93D", target:100000, current:42000, unit:"₹",    notes:"", done:false },
];

// ── sub-components ────────────────────────────────────────────────────────────
function RadialProgress({ pct, size=64, color="#FFD93D", label, sublabel }) {
  const r=(size-8)/2, circ=2*Math.PI*r, dash=circ*Math.min(pct,1);
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
      <svg width={size} height={size}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="#1E1E2E" strokeWidth={5} />
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={5}
          strokeDasharray={`${dash} ${circ}`} strokeLinecap="round"
          transform={`rotate(-90 ${size/2} ${size/2})`} style={{ transition:"stroke-dasharray .6s ease" }} />
        <text x={size/2} y={size/2+4} textAnchor="middle" fill={color} fontSize={12} fontWeight={700} fontFamily="inherit">
          {Math.round(pct*100)}%
        </text>
      </svg>
      {label    && <div style={{ fontSize:10, color:"#888", letterSpacing:1, textTransform:"uppercase", textAlign:"center" }}>{label}</div>}
      {sublabel && <div style={{ fontSize:9,  color:"#555", textAlign:"center" }}>{sublabel}</div>}
    </div>
  );
}

function GoalCard({ goal, onToggle, onDelete, onUpdateProgress }) {
  const pct = goal.target > 0 ? Math.min(goal.current/goal.target,1) : 0;
  const barColor = pct>=1?"#6BCB77":pct>=0.6?"#FFD93D":pct>=0.3?"#FF9A3C":"#4D96FF";
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(String(goal.current));
  return (
    <div style={{ background:"#13131F", border:`1px solid ${goal.done?"#6BCB7755":"#1E1E2E"}`, borderRadius:10, padding:"12px 14px", marginBottom:8, opacity:goal.done?0.7:1 }}>
      <div style={{ display:"flex", alignItems:"flex-start", gap:10 }}>
        <button onClick={() => onToggle(goal.id)} style={{ width:20, height:20, borderRadius:"50%", flexShrink:0, marginTop:2, border:`2px solid ${goal.done?"#6BCB77":goal.color}`, background:goal.done?"#6BCB77":"transparent", cursor:"pointer", fontSize:11, color:"#0E0E14", display:"flex", alignItems:"center", justifyContent:"center" }}>{goal.done?"✓":""}</button>
        <div style={{ flex:1 }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:4 }}>
            <div>
              <span style={{ fontSize:13, color:goal.done?"#666":"#F0EEE8", textDecoration:goal.done?"line-through":"none", fontWeight:600 }}>{goal.title}</span>
              {goal.category && <span style={{ marginLeft:8, fontSize:10, color:goal.color, background:goal.color+"22", borderRadius:4, padding:"2px 6px" }}>{goal.category}</span>}
            </div>
            <button onClick={() => onDelete(goal.id)} style={{ background:"none", border:"none", color:"#333", cursor:"pointer", fontSize:14, lineHeight:1, marginLeft:6 }}>×</button>
          </div>
          {goal.target > 0 && (
            <div style={{ marginBottom:6 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:4 }}>
                <span style={{ fontSize:10, color:"#555" }}>{goal.unit||"units"}</span>
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  {editing ? (
                    <input autoFocus value={val} onChange={e=>setVal(e.target.value)}
                      onBlur={() => { onUpdateProgress(goal.id,Number(val)||0); setEditing(false); }}
                      onKeyDown={e => { if(e.key==="Enter"){onUpdateProgress(goal.id,Number(val)||0);setEditing(false);}}}
                      style={{ width:54, background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:4, padding:"2px 6px", color:"#F0EEE8", fontSize:11, fontFamily:"inherit", outline:"none", textAlign:"right" }} />
                  ) : (
                    <span onClick={()=>{setEditing(true);setVal(String(goal.current));}} style={{ fontSize:11, color:barColor, cursor:"pointer", textDecoration:"underline dotted" }}>{goal.current}</span>
                  )}
                  <span style={{ fontSize:11, color:"#555" }}>/ {goal.target} {goal.unit}</span>
                </div>
              </div>
              <div style={{ background:"#1A1A26", borderRadius:3, height:5 }}>
                <div style={{ width:`${pct*100}%`, height:"100%", background:barColor, borderRadius:3, transition:"width .4s ease" }} />
              </div>
            </div>
          )}
          {goal.notes && <div style={{ fontSize:10, color:"#555", marginTop:4, fontStyle:"italic" }}>{goal.notes}</div>}
        </div>
      </div>
    </div>
  );
}

function AddGoalForm({ scope, onAdd, onCancel }) {
  const [title,setTitle]=useState(""); const [category,setCategory]=useState("");
  const [target,setTarget]=useState(""); const [unit,setUnit]=useState("");
  const [notes,setNotes]=useState(""); const [color,setColor]=useState(COLORS[3]);
  function submit() {
    if(!title.trim()) return;
    onAdd({ id:Date.now(), scope, title:title.trim(), category:category.trim(), color, target:Number(target)||0, current:0, unit:unit.trim(), notes:notes.trim(), done:false });
  }
  return (
    <div style={{ background:"#13131F", border:"1px solid #2A2A3E", borderRadius:10, padding:16, marginBottom:16 }}>
      <div style={{ fontSize:11, color:"#888", letterSpacing:1, textTransform:"uppercase", marginBottom:12 }}>New {scope==="month"?CURRENT_MONTH:CURRENT_YEAR} Goal</div>
      <input value={title} onChange={e=>setTitle(e.target.value)} onKeyDown={e=>e.key==="Enter"&&submit()} placeholder="Goal title" autoFocus style={{ width:"100%", background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"9px 12px", color:"#F0EEE8", fontSize:13, fontFamily:"inherit", outline:"none", marginBottom:8, boxSizing:"border-box" }} />
      <div style={{ display:"flex", gap:8, marginBottom:8 }}>
        <input value={category} onChange={e=>setCategory(e.target.value)} placeholder="Category" style={{ flex:1, background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"8px 12px", color:"#F0EEE8", fontSize:12, fontFamily:"inherit", outline:"none" }} />
        <input value={target} onChange={e=>setTarget(e.target.value)} placeholder="Target #" type="number" style={{ width:80, background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"8px 12px", color:"#F0EEE8", fontSize:12, fontFamily:"inherit", outline:"none" }} />
        <input value={unit} onChange={e=>setUnit(e.target.value)} placeholder="unit" style={{ width:70, background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"8px 12px", color:"#F0EEE8", fontSize:12, fontFamily:"inherit", outline:"none" }} />
      </div>
      <input value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notes (optional)" style={{ width:"100%", background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"8px 12px", color:"#F0EEE8", fontSize:12, fontFamily:"inherit", outline:"none", marginBottom:10, boxSizing:"border-box" }} />
      <div style={{ display:"flex", gap:6, marginBottom:12 }}>
        {COLORS.map(c => <button key={c} onClick={()=>setColor(c)} style={{ width:24, height:24, borderRadius:"50%", background:c, border:color===c?"3px solid #F0EEE8":"2px solid transparent", cursor:"pointer", transform:color===c?"scale(1.2)":"scale(1)", transition:"transform .1s" }} />)}
      </div>
      <div style={{ display:"flex", gap:8 }}>
        <button onClick={submit} style={{ flex:1, background:"#FFD93D", color:"#0E0E14", border:"none", borderRadius:6, padding:"9px 0", fontSize:12, fontWeight:700, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>ADD GOAL</button>
        <button onClick={onCancel} style={{ background:"transparent", color:"#666", border:"1px solid #2A2A3E", borderRadius:6, padding:"9px 14px", fontSize:12, cursor:"pointer", fontFamily:"inherit" }}>Cancel</button>
      </div>
    </div>
  );
}

// ── main app ──────────────────────────────────────────────────────────────────
export default function App() {
  // All state persisted to localStorage
  const [tab, setTab]                       = useLocalStorage("cp_tab", "todo");
  const [tasks, setTasks]                   = useLocalStorage("cp_tasks", DEFAULT_TASKS);
  const [blocks, setBlocks]                 = useLocalStorage("cp_blocks", DEFAULT_BLOCKS);
  const [completedBlocks, setCompletedBlocks] = useLocalStorage("cp_completedBlocks", {});
  const [completionLog, setCompletionLog]   = useLocalStorage("cp_completionLog", []);
  const [monthGoals, setMonthGoals]         = useLocalStorage("cp_monthGoals", DEFAULT_MONTH_GOALS);
  const [yearGoals, setYearGoals]           = useLocalStorage("cp_yearGoals", DEFAULT_YEAR_GOALS);
  const [streak, setStreak]                 = useLocalStorage("cp_streak", 4);

  // Ephemeral UI state (not persisted)
  const [newTask, setNewTask]       = useState("");
  const [newTier, setNewTier]       = useState("must");
  const [adding, setAdding]         = useState(false);
  const [blockModal, setBlockModal] = useState(null);
  const [blockLabel, setBlockLabel] = useState("");
  const [blockColor, setBlockColor] = useState(COLORS[0]);
  const [blockDuration, setBlockDuration] = useState(2);
  const [addingGoal, setAddingGoal] = useState(null);
  const [goalView, setGoalView]     = useLocalStorage("cp_goalView", "month");

  // ── derived ────────────────────────────────────────────────────────────────
  const mustTasks   = tasks.filter(t => t.tier==="must");
  const shouldTasks = tasks.filter(t => t.tier==="should");
  const somedayTasks= tasks.filter(t => t.tier==="someday");
  const mustDone    = mustTasks.filter(t => t.done).length;

  const thisWeek    = WEEK_HISTORY[WEEK_HISTORY.length-1];
  const weekAvg     = DAYS.map(d=>{const e=thisWeek.days[d];return e?e.done/e.total:0;}).reduce((a,b)=>a+b,0)/7;
  const totalScheduledHours = blocks.reduce((s,b)=>s+b.duration*.5,0);
  const scheduledDays       = [...new Set(blocks.map(b=>b.day))].length;
  const weeklyAvgs  = WEEK_HISTORY.map(wk=>DAYS.map(d=>{const e=wk.days[d];return e?e.done/e.total:0;}).reduce((a,b)=>a+b,0)/7);
  const totalBlocks    = blocks.length;
  const completedCount = Object.keys(completedBlocks).length;
  const completionRate = totalBlocks>0?completedCount/totalBlocks:0;
  const completedHours = Object.values(completedBlocks).reduce((s,b)=>s+b.duration*.5,0);

  const activeGoals = goalView==="month" ? monthGoals : yearGoals;
  const doneGoals   = activeGoals.filter(g=>g.done).length;
  const timeScope   = goalView==="month"
    ? { elapsed:dayOfMonth, total:daysInMonth, label:`${daysInMonth-dayOfMonth} days left in ${CURRENT_MONTH}` }
    : { elapsed:dayOfYear,  total:365,         label:`${365-dayOfYear} days left in ${CURRENT_YEAR}` };

  // ── handlers ───────────────────────────────────────────────────────────────
  function addTask() {
    if(!newTask.trim()) return;
    setTasks([...tasks,{id:Date.now(),text:newTask.trim(),tier:newTier,done:false}]);
    setNewTask(""); setAdding(false);
  }
  function toggleTask(id)  { setTasks(tasks.map(t=>t.id===id?{...t,done:!t.done}:t)); }
  function deleteTask(id)  { setTasks(tasks.filter(t=>t.id!==id)); }

  function openBlockModal(day,slot) {
    const existing=blocks.find(b=>b.day===day&&slot>=b.slot&&slot<b.slot+b.duration);
    if(existing){setBlocks(blocks.filter(b=>b.id!==existing.id));return;}
    setBlockModal({day,slot}); setBlockLabel("");
    setBlockColor(COLORS[Math.floor(Math.random()*COLORS.length)]); setBlockDuration(2);
  }
  function addBlock() {
    if(!blockLabel.trim()||!blockModal) return;
    setBlocks([...blocks,{id:Date.now(),day:blockModal.day,slot:blockModal.slot,label:blockLabel.trim(),color:blockColor,duration:blockDuration}]);
    setBlockModal(null);
  }
  function toggleBlockComplete(block) {
    const key=`${block.id}_${block.day}`, n=new Date();
    if(completedBlocks[key]){
      const u={...completedBlocks}; delete u[key]; setCompletedBlocks(u);
      setCompletionLog(prev=>prev.filter(l=>l.key!==key));
    } else {
      setCompletedBlocks(prev=>({...prev,[key]:{...block,completedAt:n.toISOString()}}));
      setCompletionLog(prev=>[{key,label:block.label,day:block.day,duration:block.duration,color:block.color,completedAt:n.toISOString(),time:slotToTime(block.slot)},...prev]);
    }
  }

  function addGoal(goal) {
    if(goal.scope==="month") setMonthGoals(p=>[...p,goal]);
    else setYearGoals(p=>[...p,goal]);
    setAddingGoal(null);
  }
  function toggleGoal(id,scope) {
    const setter=scope==="month"?setMonthGoals:setYearGoals;
    setter(prev=>prev.map(g=>g.id===id?{...g,done:!g.done}:g));
  }
  function deleteGoal(id,scope) {
    const setter=scope==="month"?setMonthGoals:setYearGoals;
    setter(prev=>prev.filter(g=>g.id!==id));
  }
  function updateProgress(id,val,scope) {
    const setter=scope==="month"?setMonthGoals:setYearGoals;
    setter(prev=>prev.map(g=>g.id===id?{...g,current:val,done:g.target>0?val>=g.target:g.done}:g));
  }

  const today=new Date().toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"short"});
  const TABS=[
    {id:"todo",    icon:"📋", label:"Todo"},
    {id:"timetable",icon:"🗓",label:"Schedule"},
    {id:"goals",   icon:"🎯", label:"Goals"},
    {id:"progress",icon:"📈", label:"Progress"},
  ];

  // ── render ─────────────────────────────────────────────────────────────────
  return (
    <div style={{ minHeight:"100vh", background:"#0E0E14", color:"#F0EEE8", fontFamily:"'DM Mono','Courier New',monospace", display:"flex", flexDirection:"column" }}>

      {/* ── Header ── */}
      <div style={{ padding:"20px 20px 0", borderBottom:"1px solid #1E1E2E", background:"#0E0E14", position:"sticky", top:0, zIndex:10 }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-end", marginBottom:14 }}>
          <div>
            <div style={{ fontSize:10, color:"#555", letterSpacing:2, textTransform:"uppercase", marginBottom:3 }}>Consistency Planner</div>
            <div style={{ fontSize:17, fontWeight:700, letterSpacing:-.5 }}>{today}</div>
          </div>
          <div style={{ background:"#1A1A26", border:"1px solid #2A2A3E", borderRadius:12, padding:"7px 12px", textAlign:"center" }}>
            <div style={{ fontSize:18, fontWeight:700, color:"#FFD93D" }}>🔥 {streak}</div>
            <div style={{ fontSize:9, color:"#888", letterSpacing:1 }}>STREAK</div>
          </div>
        </div>
        <div style={{ display:"flex", overflowX:"auto" }}>
          {TABS.map(t=>(
            <button key={t.id} onClick={()=>setTab(t.id)} style={{ background:"none", border:"none", borderBottom:tab===t.id?"2px solid #FFD93D":"2px solid transparent", color:tab===t.id?"#FFD93D":"#555", padding:"9px 12px", fontSize:11, letterSpacing:1.5, textTransform:"uppercase", cursor:"pointer", fontFamily:"inherit", whiteSpace:"nowrap" }}>
              {t.icon} {t.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"20px 20px 40px" }}>

        {/* ══ TODO TAB ══ */}
        {tab==="todo" && (
          <div>
            <div style={{ marginBottom:24 }}>
              <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
                <span style={{ fontSize:11, color:"#888", letterSpacing:1 }}>TODAY'S MUST-DOS</span>
                <span style={{ fontSize:11, color:mustDone===mustTasks.length&&mustTasks.length>0?"#6BCB77":"#888" }}>{mustDone} / {mustTasks.length}</span>
              </div>
              <div style={{ background:"#1A1A26", borderRadius:4, height:6 }}>
                <div style={{ background:mustDone===mustTasks.length&&mustTasks.length>0?"#6BCB77":"#FFD93D", height:"100%", borderRadius:4, width:mustTasks.length>0?`${(mustDone/mustTasks.length)*100}%`:"0%", transition:"width .4s ease" }} />
              </div>
            </div>
            {[
              {tier:"must",   label:"🎯 Must Do",   color:"#FF6B6B", tasks:mustTasks},
              {tier:"should", label:"✳️ Should Do", color:"#FFD93D", tasks:shouldTasks},
              {tier:"someday",label:"📦 Someday",   color:"#666",    tasks:somedayTasks},
            ].map(section=>(
              <div key={section.tier} style={{ marginBottom:24 }}>
                <div style={{ fontSize:11, color:section.color, letterSpacing:2, textTransform:"uppercase", marginBottom:10, display:"flex", gap:8 }}>
                  {section.label} <span style={{ color:"#444" }}>({section.tasks.length})</span>
                </div>
                {section.tasks.length===0 && <div style={{ fontSize:12, color:"#333", fontStyle:"italic" }}>No tasks here yet</div>}
                {section.tasks.map(task=>(
                  <div key={task.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"10px 14px", background:"#13131F", border:"1px solid #1E1E2E", borderRadius:8, marginBottom:6, opacity:task.done?.45:1 }}>
                    <button onClick={()=>toggleTask(task.id)} style={{ width:20, height:20, borderRadius:"50%", border:`2px solid ${task.done?"#6BCB77":section.color}`, background:task.done?"#6BCB77":"transparent", cursor:"pointer", flexShrink:0, display:"flex", alignItems:"center", justifyContent:"center", fontSize:11, color:"#0E0E14" }}>{task.done?"✓":""}</button>
                    <span style={{ flex:1, fontSize:13, textDecoration:task.done?"line-through":"none", color:task.done?"#444":"#D0CEC8" }}>{task.text}</span>
                    <button onClick={()=>deleteTask(task.id)} style={{ background:"none", border:"none", color:"#333", cursor:"pointer", fontSize:16 }}>×</button>
                  </div>
                ))}
              </div>
            ))}
            {adding?(
              <div style={{ background:"#13131F", border:"1px solid #2A2A3E", borderRadius:10, padding:16 }}>
                <input autoFocus value={newTask} onChange={e=>setNewTask(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addTask()} placeholder="What needs to get done?" style={{ width:"100%", background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"10px 12px", color:"#F0EEE8", fontSize:13, fontFamily:"inherit", outline:"none", marginBottom:12, boxSizing:"border-box" }} />
                <div style={{ display:"flex", gap:8, marginBottom:12 }}>
                  {["must","should","someday"].map(t=>(
                    <button key={t} onClick={()=>setNewTier(t)} style={{ padding:"6px 12px", borderRadius:6, border:"1px solid", borderColor:newTier===t?"#FFD93D":"#2A2A3E", background:newTier===t?"#FFD93D22":"transparent", color:newTier===t?"#FFD93D":"#666", fontSize:11, cursor:"pointer", fontFamily:"inherit", letterSpacing:1, textTransform:"uppercase" }}>{t}</button>
                  ))}
                </div>
                <div style={{ display:"flex", gap:8 }}>
                  <button onClick={addTask} style={{ flex:1, background:"#FFD93D", color:"#0E0E14", border:"none", borderRadius:6, padding:"9px 0", fontSize:12, fontWeight:700, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>ADD TASK</button>
                  <button onClick={()=>setAdding(false)} style={{ background:"transparent", color:"#666", border:"1px solid #2A2A3E", borderRadius:6, padding:"9px 14px", fontSize:12, cursor:"pointer", fontFamily:"inherit" }}>Cancel</button>
                </div>
              </div>
            ):(
              <button onClick={()=>setAdding(true)} style={{ width:"100%", background:"transparent", border:"1px dashed #2A2A3E", borderRadius:8, padding:"12px 0", color:"#444", fontSize:13, cursor:"pointer", fontFamily:"inherit" }}
                onMouseEnter={e=>{e.target.style.borderColor="#FFD93D";e.target.style.color="#FFD93D";}}
                onMouseLeave={e=>{e.target.style.borderColor="#2A2A3E";e.target.style.color="#444";}}
              >+ Add Task</button>
            )}
          </div>
        )}

        {/* ══ SCHEDULE TAB ══ */}
        {tab==="timetable" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:12 }}>
              <div style={{ fontSize:11, color:"#555" }}>Tap empty = add · Tap block = mark done</div>
              <div style={{ fontSize:11, color:"#6BCB77" }}>✓ {completedCount}/{totalBlocks}</div>
            </div>
            {totalBlocks>0&&(
              <div style={{ marginBottom:14 }}>
                <div style={{ background:"#1A1A26", borderRadius:4, height:5 }}>
                  <div style={{ background:"#6BCB77", height:"100%", borderRadius:4, width:`${completionRate*100}%`, transition:"width .4s ease" }} />
                </div>
              </div>
            )}
            <div style={{ overflowX:"auto" }}>
              <div style={{ minWidth:520, display:"flex" }}>
                <div style={{ width:44, flexShrink:0, paddingTop:28 }}>
                  {SLOTS.map(slot=>(
                    <div key={slot} style={{ height:SLOT_H, display:"flex", alignItems:"center", justifyContent:"flex-end", paddingRight:6, borderTop:slot%2===0?"1px solid #1E1E2E":"none" }}>
                      <span style={{ fontSize:9, color:slot%2===0?"#555":"transparent" }}>{slotToLabel(slot)}</span>
                    </div>
                  ))}
                </div>
                {DAYS.map(day=>(
                  <div key={day} style={{ flex:1, minWidth:0 }}>
                    <div style={{ height:28, display:"flex", alignItems:"center", justifyContent:"center", fontSize:10, color:"#888", letterSpacing:1, textTransform:"uppercase" }}>{day}</div>
                    <div>
                      {SLOTS.map(slot=>{
                        const block=blocks.find(b=>b.day===day&&b.slot===slot);
                        const covered=blocks.find(b=>b.day===day&&slot>b.slot&&slot<b.slot+b.duration);
                        if(covered) return null;
                        const key=block?`${block.id}_${block.day}`:null;
                        const isDone=key?!!completedBlocks[key]:false;
                        return (
                          <div key={slot} onClick={()=>block?toggleBlockComplete(block):openBlockModal(day,slot)}
                            title={block?(isDone?"✓ Done — click to undo":`Mark "${block.label}" done`):slotToTime(slot)}
                            style={{ height:block?`${block.duration*SLOT_H}px`:`${SLOT_H}px`, background:isDone?"#6BCB7722":block?block.color+"28":"transparent", borderTop:slot%2===0?"1px solid #1E1E2E":"1px solid #161620", borderLeft:"1px solid #1E1E2E", borderRight:"1px solid #1E1E2E", borderBottom:block?`1px solid ${isDone?"#6BCB7755":block.color+"55"}`:"none", boxSizing:"border-box", cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", overflow:"hidden", position:"relative", transition:"all .15s" }}
                            onMouseEnter={e=>{if(!block)e.currentTarget.style.background="#1A1A26";}}
                            onMouseLeave={e=>{if(!block)e.currentTarget.style.background="transparent";}}
                          >
                            {block&&(<>
                              <div style={{ position:"absolute", left:0, top:0, bottom:0, width:3, background:isDone?"#6BCB77":block.color, borderRadius:"0 2px 2px 0" }} />
                              {isDone?(
                                <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center" }}><span style={{ fontSize:14 }}>✓</span></div>
                              ):(
                                <span style={{ fontSize:block.duration>=2?9:8, color:block.color, fontWeight:700, letterSpacing:.4, textAlign:"center", padding:"0 6px", lineHeight:1.3, textTransform:"uppercase", wordBreak:"break-word" }}>{block.label}</span>
                              )}
                            </>)}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
            {completionLog.length>0&&(
              <div style={{ marginTop:24 }}>
                <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:12 }}>✅ Completion Log</div>
                {completionLog.map((entry,i)=>(
                  <div key={entry.key+i} style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 14px", background:"#13131F", border:"1px solid #1E1E2E", borderRadius:8, marginBottom:6 }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", background:entry.color, flexShrink:0 }} />
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:12, color:"#D0CEC8", fontWeight:700 }}>{entry.label}</div>
                      <div style={{ fontSize:10, color:"#555", marginTop:2 }}>{entry.day} · {entry.time} · {entry.duration*.5}h</div>
                    </div>
                    <div style={{ fontSize:10, color:"#444", textAlign:"right" }}>
                      <div>{fmtDate(new Date(entry.completedAt))}</div>
                      <div style={{ color:"#6BCB77" }}>{fmtTime(new Date(entry.completedAt))}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══ GOALS TAB ══ */}
        {tab==="goals" && (
          <div>
            <div style={{ display:"flex", background:"#13131F", border:"1px solid #1E1E2E", borderRadius:10, padding:4, marginBottom:20, gap:4 }}>
              {["month","year"].map(scope=>(
                <button key={scope} onClick={()=>{setGoalView(scope);setAddingGoal(null);}} style={{ flex:1, background:goalView===scope?"#FFD93D":"transparent", color:goalView===scope?"#0E0E14":"#666", border:"none", borderRadius:7, padding:"9px 0", fontSize:12, fontWeight:goalView===scope?700:400, cursor:"pointer", fontFamily:"inherit", letterSpacing:1, textTransform:"uppercase", transition:"all .2s" }}>
                  {scope==="month"?`📅 ${CURRENT_MONTH}`:`🗓 ${CURRENT_YEAR}`}
                </button>
              ))}
            </div>
            <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:10, padding:"10px 14px", marginBottom:16, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
              <div>
                <div style={{ fontSize:11, color:"#888", letterSpacing:1, marginBottom:4 }}>{timeScope.label}</div>
                <div style={{ background:"#1A1A26", borderRadius:3, height:4, width:160 }}>
                  <div style={{ width:`${(timeScope.elapsed/timeScope.total)*100}%`, height:"100%", background:"#FFD93D", borderRadius:3, transition:"width .4s" }} />
                </div>
              </div>
              <div style={{ textAlign:"right" }}>
                <div style={{ fontSize:18, fontWeight:700, color:"#FFD93D" }}>{doneGoals}/{activeGoals.length}</div>
                <div style={{ fontSize:10, color:"#555" }}>goals done</div>
              </div>
            </div>
            {addingGoal===goalView && <AddGoalForm scope={goalView} onAdd={addGoal} onCancel={()=>setAddingGoal(null)} />}
            {activeGoals.length===0&&addingGoal!==goalView && (
              <div style={{ textAlign:"center", padding:"40px 0", color:"#333", fontSize:13 }}>No {goalView} goals yet.<br/><span style={{ fontSize:11 }}>Add one below.</span></div>
            )}
            {activeGoals.filter(g=>!g.done).map(goal=>(
              <GoalCard key={goal.id} goal={goal} onToggle={id=>toggleGoal(id,goalView)} onDelete={id=>deleteGoal(id,goalView)} onUpdateProgress={(id,val)=>updateProgress(id,val,goalView)} />
            ))}
            {activeGoals.filter(g=>g.done).length>0&&(
              <div style={{ marginTop:16 }}>
                <div style={{ fontSize:11, color:"#6BCB77", letterSpacing:2, textTransform:"uppercase", marginBottom:10 }}>✓ Completed</div>
                {activeGoals.filter(g=>g.done).map(goal=>(
                  <GoalCard key={goal.id} goal={goal} onToggle={id=>toggleGoal(id,goalView)} onDelete={id=>deleteGoal(id,goalView)} onUpdateProgress={(id,val)=>updateProgress(id,val,goalView)} />
                ))}
              </div>
            )}
            {addingGoal!==goalView&&(
              <button onClick={()=>setAddingGoal(goalView)} style={{ width:"100%", background:"transparent", border:"1px dashed #2A2A3E", borderRadius:8, padding:"12px 0", color:"#444", fontSize:13, cursor:"pointer", fontFamily:"inherit", marginTop:8 }}
                onMouseEnter={e=>{e.target.style.borderColor="#FFD93D";e.target.style.color="#FFD93D";}}
                onMouseLeave={e=>{e.target.style.borderColor="#2A2A3E";e.target.style.color="#444";}}
              >+ Add {goalView==="month"?CURRENT_MONTH:CURRENT_YEAR} Goal</button>
            )}
          </div>
        )}

        {/* ══ PROGRESS TAB ══ */}
        {tab==="progress" && (
          <div>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:10, marginBottom:24 }}>
              <RadialProgress pct={weekAvg} size={72} color="#FFD93D" label="This Week" sublabel="avg rate" />
              <RadialProgress pct={completionRate} size={72} color="#6BCB77" label="Blocks" sublabel={`${completedCount}/${totalBlocks}`} />
              <RadialProgress pct={monthGoals.filter(g=>g.done).length/(monthGoals.length||1)} size={72} color="#FF6B6B" label={CURRENT_MONTH} sublabel="goals" />
            </div>

            <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16, marginBottom:16 }}>
              <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:14 }}>Goals Snapshot</div>
              <div style={{ display:"flex", gap:12, marginBottom:14 }}>
                {[{label:CURRENT_MONTH,goals:monthGoals,color:"#FF9A3C"},{label:String(CURRENT_YEAR),goals:yearGoals,color:"#C77DFF"}].map(({label,goals,color})=>{
                  const done=goals.filter(g=>g.done).length, pct=goals.length>0?done/goals.length:0;
                  return (
                    <div key={label} style={{ flex:1, background:"#0E0E14", border:"1px solid #1E1E2E", borderRadius:8, padding:"10px 12px" }}>
                      <div style={{ fontSize:10, color:"#666", marginBottom:4, letterSpacing:1 }}>{label}</div>
                      <div style={{ fontSize:20, fontWeight:700, color }}>{done}/{goals.length}</div>
                      <div style={{ background:"#1A1A26", borderRadius:3, height:4, marginTop:6 }}>
                        <div style={{ width:`${pct*100}%`, height:"100%", background:color, borderRadius:3, transition:"width .4s" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
              {[...monthGoals,...yearGoals].filter(g=>!g.done&&g.target>0).slice(0,4).map(g=>{
                const pct=Math.min(g.current/g.target,1);
                return (
                  <div key={g.id} style={{ marginBottom:8 }}>
                    <div style={{ display:"flex", justifyContent:"space-between", marginBottom:3 }}>
                      <span style={{ fontSize:11, color:"#888" }}>{g.title}</span>
                      <span style={{ fontSize:11, color:g.color }}>{g.current}/{g.target} {g.unit}</span>
                    </div>
                    <div style={{ background:"#1A1A26", borderRadius:3, height:4 }}>
                      <div style={{ width:`${pct*100}%`, height:"100%", background:g.color, borderRadius:3, transition:"width .4s" }} />
                    </div>
                  </div>
                );
              })}
            </div>

            {completedCount>0&&(
              <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16, marginBottom:16 }}>
                <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:12 }}>Completed Blocks</div>
                <div style={{ display:"flex", gap:16, marginBottom:10 }}>
                  <div><div style={{ fontSize:22, fontWeight:700, color:"#6BCB77" }}>{completedCount}</div><div style={{ fontSize:10, color:"#555" }}>blocks done</div></div>
                  <div><div style={{ fontSize:22, fontWeight:700, color:"#6BCB77" }}>{completedHours}h</div><div style={{ fontSize:10, color:"#555" }}>hours logged</div></div>
                </div>
                <div style={{ display:"flex", gap:6 }}>
                  {DAYS.map(day=>{
                    const dd=Object.values(completedBlocks).filter(b=>b.day===day).length;
                    const dt=blocks.filter(b=>b.day===day).length;
                    const p=dt>0?dd/dt:0;
                    return (
                      <div key={day} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
                        <div style={{ width:"100%", background:"#1A1A26", borderRadius:3, height:40, display:"flex", alignItems:"flex-end" }}>
                          <div style={{ width:"100%", height:`${Math.max(2,Math.round(p*40))}px`, background:p===1?"#6BCB77":p>0?"#FFD93D":"#1A1A26", borderRadius:"2px 2px 0 0", transition:"height .4s" }} />
                        </div>
                        <div style={{ fontSize:9, color:"#555" }}>{day}</div>
                        <div style={{ fontSize:9, color:p>0?"#6BCB77":"#333" }}>{dd}/{dt}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {completionLog.length>0&&(
              <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16, marginBottom:16 }}>
                <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:12 }}>Recent Activity</div>
                {completionLog.slice(0,5).map((entry,i)=>(
                  <div key={entry.key+i} style={{ display:"flex", alignItems:"center", gap:10, paddingBottom:10, marginBottom:10, borderBottom:i<Math.min(completionLog.length,5)-1?"1px solid #1A1A26":"none" }}>
                    <div style={{ width:8, height:8, borderRadius:"50%", background:entry.color, flexShrink:0 }} />
                    <div style={{ flex:1 }}>
                      <div style={{ fontSize:12, color:"#D0CEC8" }}>{entry.label}</div>
                      <div style={{ fontSize:10, color:"#555" }}>{entry.day} · {entry.time} · {entry.duration*.5}h</div>
                    </div>
                    <div style={{ fontSize:10, color:"#6BCB77" }}>{fmtTime(new Date(entry.completedAt))}</div>
                  </div>
                ))}
              </div>
            )}

            <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16, marginBottom:16 }}>
              <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:14 }}>This Week — Daily Must-Dos</div>
              <div style={{ display:"flex", gap:6, alignItems:"flex-end", height:80 }}>
                {DAYS.map(day=>{
                  const e=thisWeek.days[day]; const pct=e?e.done/e.total:0;
                  const barH=Math.max(4,Math.round(pct*68));
                  const color=pct===1?"#6BCB77":pct>=.5?"#FFD93D":pct>0?"#FF9A3C":"#1E1E2E";
                  return (
                    <div key={day} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                      <div style={{ fontSize:9, color:pct>0?color:"#333" }}>{e?`${e.done}/${e.total}`:"—"}</div>
                      <div style={{ width:"100%", background:"#1A1A26", borderRadius:4, height:68, display:"flex", alignItems:"flex-end", overflow:"hidden" }}>
                        <div style={{ width:"100%", height:`${barH}px`, background:color, borderRadius:"3px 3px 0 0", transition:"height .5s" }} />
                      </div>
                      <div style={{ fontSize:9, color:"#555" }}>{day}</div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16, marginBottom:16 }}>
              <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:14 }}>4-Week Trend</div>
              <div style={{ display:"flex", gap:10, alignItems:"flex-end", height:70 }}>
                {WEEK_HISTORY.map((wk,i)=>{
                  const avg=weeklyAvgs[i]; const isLatest=i===WEEK_HISTORY.length-1;
                  return (
                    <div key={wk.week} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:4 }}>
                      <div style={{ fontSize:9, color:isLatest?"#FFD93D":"#555" }}>{Math.round(avg*100)}%</div>
                      <div style={{ width:"100%", background:"#1A1A26", borderRadius:4, height:58, display:"flex", alignItems:"flex-end" }}>
                        <div style={{ width:"100%", height:`${Math.max(4,Math.round(avg*58))}px`, background:isLatest?"#FFD93D":"#2A2A3E", borderRadius:"3px 3px 0 0", transition:"height .5s" }} />
                      </div>
                      <div style={{ fontSize:9, color:isLatest?"#FFD93D":"#555", whiteSpace:"nowrap" }}>{wk.week}</div>
                    </div>
                  );
                })}
              </div>
              <div style={{ marginTop:10, fontSize:10, color:"#555", borderTop:"1px solid #1A1A26", paddingTop:10 }}>
                {weeklyAvgs[3]>=weeklyAvgs[2]?`↑ Up ${Math.round((weeklyAvgs[3]-weeklyAvgs[2])*100)}% from last week`:`↓ Down ${Math.round((weeklyAvgs[2]-weeklyAvgs[3])*100)}% from last week`}
              </div>
            </div>

            <div style={{ background:"#13131F", border:"1px solid #1E1E2E", borderRadius:12, padding:16 }}>
              <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:14 }}>Completion Heatmap</div>
              <div style={{ display:"grid", gridTemplateColumns:"32px repeat(7, 1fr)", gap:4 }}>
                <div />
                {DAYS.map(d=><div key={d} style={{ fontSize:9, color:"#555", textAlign:"center" }}>{d}</div>)}
                {WEEK_HISTORY.map((wk,wi)=>(
                  <>
                    <div key={`l${wi}`} style={{ fontSize:9, color:"#444", display:"flex", alignItems:"center" }}>{wk.week.split(" ")[1]}</div>
                    {DAYS.map(day=>{
                      const e=wk.days[day]; const pct=e?e.done/e.total:0;
                      const bg=pct===1?"#6BCB77":pct>=.67?"#6BCB7799":pct>=.34?"#FFD93D66":pct>0?"#FF6B6B44":"#1A1A26";
                      return <div key={`${wi}-${day}`} title={e?`${day} ${wk.week}: ${e.done}/${e.total}`:""} style={{ aspectRatio:"1", background:bg, borderRadius:4, border:"1px solid #0E0E14" }} />;
                    })}
                  </>
                ))}
              </div>
              <div style={{ display:"flex", gap:6, marginTop:12, alignItems:"center" }}>
                <span style={{ fontSize:9, color:"#555" }}>Less</span>
                {["#1A1A26","#FF6B6B44","#FFD93D66","#6BCB7799","#6BCB77"].map((c,i)=>(
                  <div key={i} style={{ width:12, height:12, background:c, borderRadius:3 }} />
                ))}
                <span style={{ fontSize:9, color:"#555" }}>More</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── Block Modal ── */}
      {blockModal&&(
        <div style={{ position:"fixed", inset:0, background:"#000000AA", display:"flex", alignItems:"flex-end", zIndex:100 }} onClick={()=>setBlockModal(null)}>
          <div style={{ background:"#13131F", border:"1px solid #2A2A3E", borderRadius:"16px 16px 0 0", padding:24, width:"100%", maxWidth:480, margin:"0 auto" }} onClick={e=>e.stopPropagation()}>
            <div style={{ fontSize:11, color:"#888", letterSpacing:2, textTransform:"uppercase", marginBottom:16 }}>Add Block — {blockModal.day} @ {slotToTime(blockModal.slot)}</div>
            <input autoFocus value={blockLabel} onChange={e=>setBlockLabel(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addBlock()} placeholder="Block label (e.g. Deep Work)" style={{ width:"100%", background:"#0E0E14", border:"1px solid #2A2A3E", borderRadius:6, padding:"10px 12px", color:"#F0EEE8", fontSize:13, fontFamily:"inherit", outline:"none", marginBottom:14, boxSizing:"border-box" }} />
            <div style={{ marginBottom:14 }}>
              <div style={{ fontSize:11, color:"#666", letterSpacing:1, marginBottom:8, textTransform:"uppercase" }}>Duration</div>
              <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                {DURATIONS.map(d=>(
                  <button key={d.value} onClick={()=>setBlockDuration(d.value)} style={{ padding:"7px 14px", borderRadius:6, border:"1px solid", borderColor:blockDuration===d.value?"#FFD93D":"#2A2A3E", background:blockDuration===d.value?"#FFD93D22":"transparent", color:blockDuration===d.value?"#FFD93D":"#666", fontSize:12, cursor:"pointer", fontFamily:"inherit" }}>{d.label}</button>
                ))}
              </div>
            </div>
            <div style={{ marginBottom:20 }}>
              <div style={{ fontSize:11, color:"#666", letterSpacing:1, marginBottom:8, textTransform:"uppercase" }}>Color</div>
              <div style={{ display:"flex", gap:8 }}>
                {COLORS.map(c=>(
                  <button key={c} onClick={()=>setBlockColor(c)} style={{ width:28, height:28, borderRadius:"50%", background:c, border:blockColor===c?"3px solid #F0EEE8":"2px solid transparent", cursor:"pointer", transition:"transform .15s", transform:blockColor===c?"scale(1.2)":"scale(1)" }} />
                ))}
              </div>
            </div>
            <button onClick={addBlock} style={{ width:"100%", background:"#FFD93D", color:"#0E0E14", border:"none", borderRadius:8, padding:"12px 0", fontSize:13, fontWeight:700, cursor:"pointer", fontFamily:"inherit", letterSpacing:1 }}>ADD BLOCK</button>
          </div>
        </div>
      )}
    </div>
  );
}
